<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" type="text/css" href="style.css">

 <title>Document</title>
</head>
<body>
<?php include "menu.php"; ?>
<?php require_once "connect.php"; ?>

<div class="container">
                <h1>Medication Record Form</h1>


                <?php
                    if(isset($_SESSION['message'])): ?>

                    <?php
                     echo $_SESSION['message'];
                     unset ($_SESSION['message']);
                     ?>
                <?php endif ?>
               
<form action="connect.php" method="POST">

    
            <input type="text" name="medicine_name" value="<?php echo $medicine_name; ?>" placeholder="Medicine Name" class="sec_input">
        
            <input type="date" name="date" value="<?php echo $date; ?>" placeholder="date" class="sec_input">
            <input type="time" name="time" value="<?php echo $time; ?>" placeholder="time" class="sec_input">
      
       
 

    <tr>
        <td colspan="2">
            <input type="submit" name="save_dose" value="save_dose" class="btn-secondary">
        </td>
    </tr>


</form>


<?php  
    $mysqli = new mysqli('localhost','root','usbw','medicine') or die(mysqli_error($mysqli));
    $res = $mysqli->query("SELECT * FROM med_log") or die($mysqli->error);
    ?>

 <!-- Main Content Section Starts -->
 <div class="main">
            <div class="container">

            
                <h1>Medication Table</h1>

              

                <table class="tbl-full">
                   <thead>
                   <tr>
                        <th>Medicine Name</th>
                        <th>Date</th>
                        <th>Time</th>




                    </tr>
 
                   </thead>
                 
                    <?php 
                      while ($row = $res->fetch_assoc()):
                    ?>
                    <tr>
                        <td><?php echo $row ['medicine_name'];?></td>
                        <td><?php echo $row ['date'];?></td>
                        <td><?php echo $row ['time'];?></td>
                    


                        </tr>
                        <?php endwhile ?>

                      
                </table>

                <?php
    function pre_r($array){
        echo '<pre>';
        print_r($array);
        echo '</pre>';
    }

    ?>
           

    </div>
    </div>

</body>
</html>