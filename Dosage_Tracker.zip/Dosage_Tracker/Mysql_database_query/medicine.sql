-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 23, 2021 at 06:42 AM
-- Server version: 5.6.34
-- PHP Version: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `medicine`
--

-- --------------------------------------------------------

--
-- Table structure for table `dose`
--

CREATE TABLE `dose` (
  `id` int(11) NOT NULL,
  `medicine_name` varchar(50) CHARACTER SET utf8 NOT NULL,
  `dosage` varchar(100) CHARACTER SET utf8 NOT NULL,
  `miligram` int(11) NOT NULL,
  `frequency` varchar(100) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dose`
--

INSERT INTO `dose` (`id`, `medicine_name`, `dosage`, `miligram`, `frequency`) VALUES
(213, 'Malfan', 'injection', 5, 'once daily'),
(214, 'Atesunate', 'tablet', 500, 'three times a day'),
(215, 'Amoxiline', 'capsule', 500, 'three times a day'),
(216, 'Chloraphenicol', 'Eye drop', 4, 'Every 3 hours');

-- --------------------------------------------------------

--
-- Table structure for table `med_log`
--

CREATE TABLE `med_log` (
  `id` int(11) NOT NULL,
  `medicine_name` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `med_log`
--

INSERT INTO `med_log` (`id`, `medicine_name`, `date`, `time`) VALUES
(51, 'Malfan', '2021-04-09', '12:23:00'),
(54, 'Cypro', '2021-04-03', '15:06:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dose`
--
ALTER TABLE `dose`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `med_log`
--
ALTER TABLE `med_log`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dose`
--
ALTER TABLE `dose`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=217;

--
-- AUTO_INCREMENT for table `med_log`
--
ALTER TABLE `med_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
